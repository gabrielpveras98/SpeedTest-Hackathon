<!DOCTYPE html>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <div class="title-cab">
        <title id="title-cab">Menino Da T.I</title></div>
        <link type="text/js" href="../../vendor/bootstrap/js/bootstrap.bundle.min.js"/>
        <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.min.css"  crossorigin="anonymous">
        <link href="main.css?version=12" />
        <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

        
    <script src="../../vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <script src="../../vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
        <link type="text/css" href="inicio.css" />
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
</head>
    <body>
<!-- Imagem e texto --><nav class="navbar navbar-expand-lg navbar-dark bg-danger">
<div class="container">
<a class="navbar-brand" href="#">
    Menino da T.I
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Alterna navegação">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse " id="navbarNavDropdown">
    <ul class="navbar-nav float-rigth">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(Página atual)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="https://play.google.com/store/apps?hl=pt_BR">Baixar App</a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link" href="../inicial/formulario/login.php">Ser parceiro
        </a>
      </li>
      
    </ul>
  </div>
</nav>
</div>
    
    <link type="text/js" href="../../vendor/bootstrap/js/bootstrap.bundle.min.js"/>
    <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
    <link href="main.css?version=12"/>
    <link type="text/css" href="inicio.css"/>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
</body>
