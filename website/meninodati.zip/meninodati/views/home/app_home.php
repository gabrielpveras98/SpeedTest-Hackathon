<?php

require_once "../inicial/modelo/cabecalho_app.php";
?>

<html>

<head>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <script type="text/js" src="pace.mim.js"></script>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
</head>
<body>
<div class="jumbotron jumbotron-fluid col-12">
    <div class="container text-jumb">
   <p style="font-size:60px;">
       Soluções rápidas 
   </p>
   <p style="font-size:26px;">
       para os seus problemas técnicos
   </p>
    </div>
</div>

    <div class="escolha">
        
<div class="escolha container" href="https://play.google.com/store/?utm_source=latam_Med&utm_medium=hasem&utm_content=Feb0217&utm_campaign=Evergreen&pcampaignid=MKT-DR-latam-br-1002290-Med-hasem-py-Evergreen-Feb0217-Text-Institucional&gclid=Cj0KCQiAno_uBRC1ARIsAB496IWDW1uwOgtvWV9OrChoL56CSfjH5hBitc63PxLKYzeJ_BAg2TNtb8kaAuBNEALw_wcB&gclsrc=aw.ds">
    <div class="center"> 
 <div class="row">
  <div class="col-lg-4">
      <a href="https://play.google.com/store/apps?hl=pt_BR">
      <img src="../../public/img/baixar.png" alt="Imagem baixar"  height="120px">
      <h4>Baixar o App </h4></a>
</div>
</a>
<div class="row">
  <div class=" col-lg-4">
  <a href="../inicial/formulario/login.php">
      <img src="../../public/img/empresa.png" alt="Imagem baixar"  height="120px">
      <h4 id="parceiro" style="width:132px;"> Ser parceiro </h4>
  </a>
</div>
</div>
</div>
</div>
 </div>
    </div>
<hr>
<!-- /.row -->
  <!-- Marketing messaging and featurettes
  ================================================== -->
  <!-- Wrap the rest of the page in another container to center all the content. -->
<div class="info container">
    <h1 class="text-center">Serviços</h1>
    <br>
  <div class="container marketing container" id="info">

<!-- Three columns of text below the carousel -->
<div class="row">
  <div class="col-lg-4">
    <i class='fas fa-laptop' style='font-size:100px; color:#0187B7' ></i>
    <h2>Formatação</h2>
    <p>Nossa técnica de formatação é até 85% mais rápida que as formatações convencionais e proporciona maior segurança aos seus arquivos. </p>
    
  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
  <i class='fas fa-user' style='font-size:100px;color:#0187B7'></i>
  <h2>Suporte técnico</h2>
    <p>Nossos técnicos são especialistas e podem resolver problemas com seu Computador, Impressora, Arquivos, Acessórios, Wi-Fi, Internet, Instalação de Softwares.</p>
  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
  <i class="fa fa-wrench" style="font-size:100px;color:#0187B7;"></i>
  <h2>Reparos genéricos</h2>
    <p>Consertamos Equipamentos de Informática, Smartphones, Notebook, Monitores, No-breaks. Orçamento sem compromisso com retirada e entrega no local sem custo adicional.</p>
  </div><!-- /.col-lg-4 -->
</div><!-- /.row -->

<div class="container marketing container">
<hr>
<!-- Three columns of text below the carousel -->
<div class="row">
  <div class="col-lg-4">
  <i class="fa fa-wifi" style="font-size:100px; color:#0187B7;"></i>
  <h2>Wi-fi</h2>
    <p>Realizamos a instalação de rede wi-fi com melhoria de sinal para todos os cômodos da casa ou escritório. Configuração e ajustes finos de frequência e canais com melhor velocidade de navegação.</p>
  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
  <i class="fa fa-desktop" style="font-size:100px;color:#0187B7;"></i>
  <h2>SmartTV</h2>
    <p>Realizamos a instalação e configuração da sua SmartTV. Conectamos na sua rede WiFi e realizamos instalação dos canais de HDTV e CABO. Instruções para uso dos Apps Netflix YouTube e outros.</p>
  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
  <i class='fas fa-cart-plus' style='font-size:100px;color:#0187B7;'></i> 
  <h2>Peças e Acessórios</h2>
    <p>Temos peças para os principais fabricantes como Dell, Lenovo, Positivo, HP e Apple. Encontre Teclado, mouse, Placa de Vídeo, memória, Fonte, Placa mãe, Telas, Monitores, adaptadores e muito mais.</p>
  </div><!-- /.col-lg-4 -->
</div><!-- /.row -->

</div>


  </div>
</div>






<hr>
<!-- /.row -->
  <!-- Marketing messaging and featurettes
  ================================================== -->
  <!-- Wrap the rest of the page in another container to center all the content. -->
<div class="info container">
    <h1 class="text-center">Parceiros</h1>
    <br>
  <div class="container marketing container" id="info">

<!-- Three columns of text below the carousel -->
<div class="row">
  <div class="col-lg-4">
    <img src="../../public/img/json.png" alt="" width="135px">
    <br>
    <p style="padding-top:8%;">Jason é uma empresa que presta o mais diversos serviços de T.I com profissionais capacitados e um serviço de qualidade. </p>
    
  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
  <img src="../../public/img/json.png" alt="" width="135px">
    <p  style="padding-top:8%;">Nossos técnicos são especialistas e podem resolver problemas com seu Computador, Impressora, Arquivos, Acessórios, Wi-Fi, Internet, Instalação de Softwares.</p>
  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
  <img src="../../public/img/json.png" alt="" width="135px">
    
    <p  style="padding-top:8%;">Nossos técnicos são especialistas e podem resolver problemas com seu Computador, Impressora, Arquivos, Acessórios, Wi-Fi, Internet, Instalação de Softwares.</p>
</div><!-- /.col-lg-4 -->
</div><!-- /.row -->

  </div>
</div>













<hr>
<br>
<?php
require_once "../inicial/modelo/rodape.php";
?>
<br>
</body>
</html>